<p align="center">
<a href="https://h4ck3r0.github.io/"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://h4ck3r0.github.io/"><img title="Made in INDIA" src="https://img.shields.io/badge/Tool-Apktool-green.svg?style=flat-square"></a>
<a href="https://h4ck3r0.github.io/"><img title="Version" src="https://img.shields.io/badge/Version-1.0-green.svg?style=flat-square"></a>
<a href="https://h4ck3r0.github.io/"><img title="Maintainence" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg?style=flat-square"></a>
</p>
<p align="center">
 <a href=""><img src="https://user-images.githubusercontent.com/46929618/150729143-6180cef9-6625-44b6-a27f-1da95c9af153.png" width="1000" hight="300"></a>
</p>
<p align="center">
<a href="https://github.com/h4ck3r0"><img title="Github" src="https://img.shields.io/badge/H4CK3R-RAJ-brightgreen?style=for-the-badge&logo=github"></a>
<a href="https://youtu.be/VDeLnDxVziw"><img title="YouTube" src="https://img.shields.io/badge/YouTube-H4CK3R-red?style=for-the-badge&logo=Youtube"></a>
</p>
<p align="center">
<a href="https://github.com/h4ck3r0"><img title="Language" src="https://img.shields.io/badge/Made%20with-Bash-1f425f.svg?v=103&style=flat-square"></a>
<a href="https://github.com/h4ck3r0"><img title="Followers" src="https://img.shields.io/github/followers/h4ck3r0?color=blue&style=flat-square"></a>
<a href="https://github.com/h4ck3r0"><img title="Stars" src="https://img.shields.io/github/stars/h4ck3r0/Apktool-termux?color=red&style=flat-square"></a>
<a href="https://github.com/h4ck3r0"><img title="Forks" src="https://img.shields.io/github/forks/h4ck3r0/Apktool-termux?color=red&style=flat-square"></a>
<a href="https://github.com/h4ck3r0"><img title="Watching" src="https://img.shields.io/github/watchers/h4ck3r0/Apktool-termux?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/h4ck3r0"><img title="Licence" src="https://img.shields.io/badge/License-GNU-blue.svg?style=flat-square"></a>
</p>


### Apktool-termux


* [-] Latest apktool 2.9.3 for Termux by H4Ck3R

* [-] Version : 2.9.3


### AVAILABLE ON :

* Termux

### REQUIREMENTS :

* Java


### FEATURES :
* [+] Latest Apktool !
* [+] Java  !
* [+] Error Fix !
* [+] Fully Automatic !
* [+] Easy for Beginners !

## INSTALLATION [Termux] :

* `apt-get update -y`
* `apt-get upgrade -y`
* `git clone https://github.com/h4ck3r0/Apktool-termux`
* `cd $HOME`
* `ls`
* `cd Apktool-termux`
* `chmod +x *`
* `bash setup.sh`
* `bash apktool.sh`
```
[+]-- Open new session in termux and Type apktool
```

## [Full Installation](https://www.google.com/search?q=How%20to%20install%20apktool%20in%20termux%20site%3Ah4ck3r.me) 
More Uses : [Click Here](https://www.h4ck3r.me/the-power-of-apktool-apktool-usage/)
## Credit

* Script by H4Ck34 (Raj Aryan)
 
* apktool 
 
* Java
 
## Error Solve

```
• If u using android 8+

• U get java error

• So type proot -0

• Then run apktool
```
## CONNECT WITH US :
<a href="https://www.buymeacoffee.com/h4ck3r" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

<a href="https://github.com/h4ck3r0"><img title="Github" src="https://img.shields.io/badge/H4Ck3R-Raj-brightgreen?style=for-the-badge&logo=github"></a>
[![Instagram](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/h4ck3r0_official?igsh=NzN1NTNucWhjOXJp)
[![Instagram](https://img.shields.io/badge/WEBSITE-VISIT-yellow?style=for-the-badge&logo=blogger)](https://www.h4ck3r.me)
[![Instagram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://t.me/h4ck3r_group)
<a href="https://rebrand.ly/7elzgww"><img title="YouTube" src="https://img.shields.io/badge/YouTube-H4Ck3R-red?style=for-the-badge&logo=Youtube"></a>
https://www.h4ck3r.me/how-to-install-apktool-in-termux/
